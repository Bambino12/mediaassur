export default{
	status: 1,
	establishments: [
	  	{
	  		id: 1,
		  	label: 'Gecos Formation'
		},
		{
	  		id: 2,
		  	label: 'Loko'
		},
		{
	  		id: 3,
		  	label: 'Point Carre'
		},
	],
	filieres: [
	  	{
	  		id: 1,
		  	label: 'IDA'
		},
		{
	  		id: 2,
		  	label: 'GESCOM'
		},
		{
	  		id: 3,
		  	label: 'RIT'
		},
	],
	nevels: [
	  	{
	  		id: 1,
		  	label: 'Bac 1'
		},
		{
	  		id: 2,
		  	label: 'Bac 2'
		},
		{
	  		id: 3,
		  	label: 'Bac 3'
		},
	],
}
