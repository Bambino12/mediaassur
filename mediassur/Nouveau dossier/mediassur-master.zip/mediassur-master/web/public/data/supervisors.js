export default [
  {
    id: 'DEV730658',
    firstName: "Christian",
    lastName: 'Yao',
    tel: "01020304",
  },
  {
    id: 'DEV898812',
    firstName: "Dagobert",
    lastName: 'Dago',
    tel: "61020304",
  },
  {
    id: 'DEV793788',
    firstName: "Djidji",
    lastName: 'Djadja',
    tel: "45021304",
  }
];
