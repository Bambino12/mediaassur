export const logo = `${process.env.PUBLIC_URL}/images/mediassur.jpeg`; 
export const logo2 = `${process.env.PUBLIC_URL}/images/logo.jpg`; 

export const bg_Mediassur = `${process.env.PUBLIC_URL}/images/bg_Mediassur.jpg`; 

export const sign_in_image = `${process.env.PUBLIC_URL}/images/banner4.jpg`;
export const sign_up_image = `${process.env.PUBLIC_URL}/images/banner4.jpg`;

//Article image
export const article_image = `${process.env.PUBLIC_URL}/images/article_image.jpg`;

// Banners
export const banner1 = `${process.env.PUBLIC_URL}/images/banner1.jpg`;
export const banner2 = `${process.env.PUBLIC_URL}/images/banner2.jpg`;
export const banner3 = `${process.env.PUBLIC_URL}/images/banner3.jpg`;
export const banner4 = `${process.env.PUBLIC_URL}/images/banner4.jpg`;

export const avatar = `${process.env.PUBLIC_URL}/images/avatar.jpg`;
export const avatar_yao = `${process.env.PUBLIC_URL}/images/avatar_yao.jpg`;
export const avatar_kakou = `${process.env.PUBLIC_URL}/images/avatar_kakou.jpg`;
