export const PUBLIC_ROUTE = 'http://127.0.0.1:3000/data';
export const API_ROUTE = 'http://127.0.0.1:3000/data';
export const ARTICLES_IMAGES_ROUTE = PUBLIC_ROUTE+'/images/products';
export const GRAPQL_API_ROUTE = 'http://localhost:8000/graphql';