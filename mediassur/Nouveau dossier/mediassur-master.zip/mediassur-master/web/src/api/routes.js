import {API_BASE_URL} from '../constant'
//export const PUBLIC_ROUTE = 'http://192.168.1.101:8080/v1';
export const PUBLIC_ROUTE = API_BASE_URL  + '';
//export const API_BASE_ROUTE = 'http://192.168.1.101:8080';
export const API_BASE_ROUTE = 'http://localhost:8080';
export const API_ROUTE =  API_BASE_URL;