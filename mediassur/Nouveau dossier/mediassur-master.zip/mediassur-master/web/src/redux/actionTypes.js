export const SIGN_IN = 'SIGN_IN'
export const LOG_OUT = 'LOG_OUT'
